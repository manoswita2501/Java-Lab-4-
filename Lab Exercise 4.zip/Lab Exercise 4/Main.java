import doctors.GeneralPractitioner;
import nurses.RegisteredNurse;

public class Main {
    public static void main(String[] args) {
        // Create instances of healthcare professionals
        GeneralPractitioner gp = new GeneralPractitioner();
        RegisteredNurse nurse = new RegisteredNurse();

        // Perform healthcare activities
        System.out.println("Activities of General Practitioner:");
        gp.diagnose();
        gp.treat();
        gp.prescribeMedication();

        System.out.println("\nActivities of Registered Nurse:");
        nurse.diagnose();
        nurse.treat();
        nurse.administerMedication();
    }
}
