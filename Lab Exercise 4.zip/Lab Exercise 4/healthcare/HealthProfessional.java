
package healthcare;

public interface HealthProfessional {
    void diagnose();

    void treat();
}
