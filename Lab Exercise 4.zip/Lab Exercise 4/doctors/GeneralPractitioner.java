package doctors;

import healthcare.HealthProfessional;

public class GeneralPractitioner implements HealthProfessional {
    @Override
    public void diagnose() {
        System.out.println("General Practitioner is diagnosing the patient.");
    }

    @Override
    public void treat() {
        System.out.println("General Practitioner is treating the patient.");
    }

    public void prescribeMedication() {
        System.out.println("General Practitioner is prescribing medication.");
    }
}
