
package nurses;

import healthcare.HealthProfessional;

public class RegisteredNurse implements HealthProfessional {
    @Override
    public void diagnose() {
        System.out.println("Registered Nurse is assisting in patient diagnosis.");
    }

    @Override
    public void treat() {
        System.out.println("Registered Nurse is providing care to the patient.");
    }

    public void administerMedication() {
        System.out.println("Registered Nurse is administering medication.");
    }
}
